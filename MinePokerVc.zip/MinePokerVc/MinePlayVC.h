//
//  MinePlayVC.h
//  PokerDemo
//
//  Created by iOSlmm on 2018/10/16.
//  Copyright © 2018年 iOSlmm. All rights reserved.
//

#import "BaseVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface MinePlayVC : BaseVC

@end

NS_ASSUME_NONNULL_END
