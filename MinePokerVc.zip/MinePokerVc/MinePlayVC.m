//
//  MinePlayVC.m
//  PokerDemo
//
//  Created by iOSlmm on 2018/10/16.
//  Copyright © 2018年 iOSlmm. All rights reserved.
//

#import "MinePlayVC.h"
#import "AppDelegate.h"
#import "MinePokerView.h"
#import "PreviousPokerView.h"
#import "NextPokerView.h"
#import "OppositePokerView.h"
#import "SocketRocket.h"
#import "PokerMemModel.h"
#import "PokerModel.h"
#import "SeatsModel.h"
#import "BrightMainView.h"
#import "UpgradeModel.h"
#import "PokerView.h"
#define countcoordinatesY(A) [UIScreen mainScreen].bounds.size.height * (A / 375.f)

@interface MinePlayVC ()<SRWebSocketDelegate>
{
    UIView *_originalSuperview;
    CGRect _originalRect;
    // 是否旋转屏幕
    BOOL _isRotate;
    // 是否是第一次进入
    BOOL _firstIn;
    // 链接
    NSString *_url;
    // 手机号
    NSString *_phone;
    NSMutableArray *seatsArr;//座位数据
    NSString *currentIndex;//当前桌子的索引
    NSString *currentSeatIndex;//当前椅子的索引

}
@property(nonatomic,strong) UIButton *start;//准备
@property (nonatomic,strong)SRWebSocket *webSocket;
@property (nonatomic,strong)MinePokerView *mineview;
@property (nonatomic,strong)PreviousPokerView *previousView;
@property (nonatomic,strong)OppositePokerView *oppoView;
@property (nonatomic,strong)NextPokerView *nextView;
@property (nonatomic,strong)UIButton *trusteeship;//托管
@property (nonatomic,strong)BrightMainView *brightView;//亮主
@property (nonatomic,strong)NSString *sessionId;
@property (nonatomic,strong)NSString *membID;//游戏memberID
@property (nonatomic,strong)UpgradeModel *upModel;
@property (nonatomic,strong)UIView *hitBgView;//打牌背景区域
@end

@implementation MinePlayVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"打牌啊";
    [self.navigationController.navigationBar setHidden:YES];
    currentIndex = @"3";
    currentSeatIndex = @"0";
    _firstIn = YES;
    _isRotate = NO;

    [self bgView];
    [self initPreviousPokerView];
    [self initOppositePokerView];
    [self initNextPokerView];
    [self initMinePokerView];
//    [self WSrequest];
    [self initWebSocket];
    [self prepareBtn];
    [self backBtn];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(clear) name:kNotification_ClearMessagePoker object:nil];

}

- (void)initWebSocket {
//    ws://192.168.1.15:80/GameLobby/communication 内网
//    ws://120.55.63.48:80/GameLobby/communication 外网
    //Url
    self.webSocket = [[SRWebSocket alloc]initWithURLRequest:
                      [NSURLRequest requestWithURL:[NSURL URLWithString:POKER_URL]]];
    //代理协议
    self.webSocket.delegate = self;
    //直接连接`
    [self.webSocket open];    // open 就是直接连接了
 
}

- (void)bgView {
    UIImageView *bgimg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_HEIGHT, SCREEN_WIDTH)];
    bgimg.image = [UIImage imageNamed:@"bg"];
    [self.view addSubview:bgimg];
}
- (void)prepareBtn {
    _start = [UIButton buttonWithType:UIButtonTypeCustom];
    _start.frame = CGRectMake((SCREEN_HEIGHT-95)/2, (SCREEN_WIDTH-44)/2, 95, 44);
    [_start setImage:[UIImage imageNamed:@"btnPrepare"] forState:UIControlStateNormal];
    [self.view addSubview:_start];
    _start.hidden = YES;
    
    [_start addTarget:self action:@selector(prepareAct) forControlEvents:UIControlEventTouchUpInside];
//    托管
    _trusteeship = [UIButton buttonWithType:UIButtonTypeCustom];
    _trusteeship.frame = CGRectMake((SCREEN_HEIGHT-115), 10, 80, 38);
    [_trusteeship setBackgroundImage:[UIImage imageNamed:@"mandate"] forState:UIControlStateNormal];
    [_trusteeship setImage:[UIImage imageNamed:@"update_choose_none"] forState:UIControlStateNormal];
    [_trusteeship setImage:[UIImage imageNamed:@"update_choose"] forState:UIControlStateSelected];
    _trusteeship.imageEdgeInsets = UIEdgeInsetsMake(5, 11, 11, 48);

    [self.view addSubview:_trusteeship];
    [_trusteeship addTarget:self action:@selector(trusteeshipAct:) forControlEvents:UIControlEventTouchUpInside];
}
- (void)backBtn
{
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(20, 15, 32, 32);
    [backBtn setImage:[UIImage imageNamed:@"hall"] forState:UIControlStateNormal];
    [self.view addSubview:backBtn];
    [backBtn addTarget:self action:@selector(backAct) forControlEvents:UIControlEventTouchUpInside];
}
#pragma mark btnAct
//准备
- (void)prepareAct {
    NSDictionary *pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"prepare",@"memberId":self.membID};
    NSString *parmStr = [pardic mj_JSONString];
    [_webSocket send:parmStr];
}
- (void)withdrawAct {
    //撤销
    NSDictionary *pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"withdraw",@"memberId":self.membID};
    NSString *parmStr = [pardic mj_JSONString];
    [_webSocket send:parmStr];
}
//托管
- (void)trusteeshipAct:(UIButton *)sender
{
    sender.selected = !sender.selected;
    NSDictionary *pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"mandate",@"memberId":self.membID,@"mandated":sender.selected?@YES:@NO};
    NSString *parmStr = [pardic mj_JSONString];
    [_webSocket send:parmStr];
}
- (void)backAct {
    //撤销
    NSDictionary *pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"stand",@"memberId":self.membID};
    NSString *parmStr = [pardic mj_JSONString];
    [_webSocket send:parmStr];
    [self.navigationController popViewControllerAnimated:YES];
    [self setVerticalScreen];
}
#pragma mark initView
- (BrightMainView *)brightView
{
    if (!_brightView) {
        _brightView = [BrightMainView loadLastNib:CGRectMake(0,SCREEN_HEIGHT-countcoordinatesY(125)-50 , (188), (50))];
        _brightView.centerX = self.view.centerX;
        [self.view addSubview:_brightView];
        WS(weakself);
        [_brightView setBlock:^(int index) {
            NSDictionary *pardic = @{@"sessionId":weakself.sessionId,@"command":@"upgrade",@"subcommand":@"scramble",@"memberId":weakself.membID,@"colourIndex":@(index)};
            NSString *parmStr = [pardic mj_JSONString];
            [weakself.webSocket send:parmStr];
        }];
    }
    return _brightView;
}
- (UIView *)hitBgView
{
    if (_hitBgView) {
        _hitBgView = [[UIView alloc]initWithFrame:CGRectMake(10,SCREEN_HEIGHT-countcoordinatesY(125)-50, SCREEN_WIDTH-20, countcoordinatesY(80))];
        _hitBgView.backgroundColor = [UIColor redColor];
        [self.view addSubview:_hitBgView];
        
    }
    return _hitBgView;
}
- (void)initPreviousPokerView {
    _previousView = [[PreviousPokerView alloc]initWithFrame:CGRectMake(countcoordinatesX(20), countcoordinatesX(80), countcoordinatesX(200), countcoordinatesX(200))];
    [self.view addSubview:_previousView];
}
//对家
- (void)initOppositePokerView {
    _oppoView = [[OppositePokerView alloc]initWithFrame:CGRectMake(countcoordinatesX(350), countcoordinatesX(30), countcoordinatesX(200), countcoordinatesX(200))];
    _oppoView.centerX = self.view.centerX;
    _oppoView.hidden = YES;
    [self.view addSubview:_oppoView];
}
- (void)initNextPokerView {
    _nextView = [[NextPokerView alloc]initWithFrame:CGRectMake(SCREEN_HEIGHT - countcoordinatesX(220), countcoordinatesX(120), countcoordinatesX(200), countcoordinatesX(200))];
    _nextView.hidden = YES;
    [self.view addSubview:_nextView];
}
- (void)initMinePokerView
{
    _mineview = [[MinePokerView alloc]initWithFrame:CGRectMake(countcoordinatesX(10), SCREEN_WIDTH-countcoordinatesX(125), SCREEN_HEIGHT-countcoordinatesX(20), countcoordinatesX(120)) arr:@[]];
    _mineview.arr = @[];
    [self.view addSubview:_mineview];
}
//出牌
- (void)initHitPokerView:(NSArray *)arr {
    
    if (_hitBgView) {
        [_hitBgView removeFromSuperview];
    }
    _hitBgView = [[UIView alloc]initWithFrame:CGRectMake((self.view.width-countcoordinatesY(39))/2, self.view.height-countcoordinatesY(185),(arr.count-1)*countcoordinatesY(15)+countcoordinatesY(39), countcoordinatesY(60))];
    _hitBgView.hidden = YES;
    [self.view addSubview:_hitBgView];
    
    
    for (int i = 0; i<arr.count; i++) {
        PokerView *pview = [[PokerView alloc]initWithFrame:CGRectMake(i*countcoordinatesY(15), 0, countcoordinatesY(39), countcoordinatesY(60))];
        _hitBgView.frame = CGRectMake((self.view.width-countcoordinatesY(39)-i*countcoordinatesY(15))/2, self.view.height-countcoordinatesY(185),(arr.count-1)*countcoordinatesY(20)+countcoordinatesY(39), countcoordinatesY(60));
        _hitBgView.hidden = NO;
        PokerModel *model = arr[i];
        pview.model = model;
        [_hitBgView addSubview:pview];
    }
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setHorizontalScreen];
}

#pragma mark 实现代理**
- (void)webSocketDidOpen:(SRWebSocket *)webSocket {
    NSLog(@"连接成功，可以立刻登录你公司后台的服务器了，还有开启心跳");
}
-(void)webSocket:(SRWebSocket *)webSocket didFailWithError:(NSError *)error {
    NSLog(@"连接失败，这里可以实现掉线自动重连，要注意以下几点%@",error);
    
    //关闭心跳包
    [webSocket close];
}
//连接断开
- (void)webSocket:(SRWebSocket *)webSocket didCloseWithCode:(NSInteger)code reason:(NSString *)reason wasClean:(BOOL)wasClean {
    
    //关闭心跳包
    [webSocket close];
}
//接收到数据
- (void)webSocket:(SRWebSocket *)webSocket didReceiveMessage:(id)message  {
    // 收到数据后,你要给后台发送的数据.
    //将收到的json数据转换成字典
   
    NSDictionary *dataDic = [message mj_JSONObject];
    _upModel = [UpgradeModel mj_objectWithKeyValues:dataDic];
    NSDictionary *pardic;
//    NSLog(@"接收到数据%@",dataDic);
    NSString *command = _upModel.command;
    NSLog(@"接收到数据%@----%@",command,_upModel.subcommand);

    if ([command isEqualToString:@"getSessionId"]) {
        self.sessionId = [dataDic objectForKey:@"sessionId"];
        pardic = @{@"sessionId":self.sessionId,@"command":@"login",@"account":@"kawaguchi",@"cipher":@"123"};
       
    }
    if ([command isEqualToString:@"login"]) {
        int online = [[dataDic objectForKey:@"online"] intValue];
        self.membID = [NSString stringWithFormat:@"%@",[dataDic objectForKey:@"id"]];
        SeatMembModel *memmodel = [SeatMembModel mj_objectWithKeyValues:dataDic];
        _mineview.smodel = memmodel;

        if (online == 1) {//已在线，踹
            pardic = @{@"sessionId":self.sessionId,@"command":@"kickoff",@"memberId":self.membID,@"currentSessionId":self.sessionId};
        }else
        {
            pardic = @{@"sessionId":self.sessionId,@"command":@"onlineMember",@"memberId":self.membID,@"currentSessionId":self.sessionId};//上线会员
        }
       
    }else if ([command isEqualToString:@"kickoff"]){
        pardic = @{@"sessionId":self.sessionId,@"command":@"onlineMember",@"memberId":self.membID,@"currentSessionId":self.sessionId};//上线会员
        
    }else  if ([command isEqualToString:@"onlineMember"]) {//获取游戏
        pardic = @{@"sessionId":self.sessionId,@"command":@"getGames"};

    }else  if ([command isEqualToString:@"getGames"]) {//根据名称获得游戏
        NSDictionary *game = [dataDic objectForKey:@"games"][0];
        pardic = @{@"sessionId":self.sessionId,@"command":@"getGameByName",@"gameName":[game objectForKey:@"name"]};
      
    }else  if ([command isEqualToString:@"getGameByName"]) {
        pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"getBattles"};//得到作战

//        pardic = @{@"sessionId":sessionId,@"command":@"getFriendships",@"memberId":membID};
        
    }else if ([command isEqualToString:@"getFriendships"]) {
        pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"getBattles"};
       
    }else if ([command isEqualToString:@"exit"]) {//退出
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"getBattles"]) {//升级，得到作战
        //z刚开始坐的时候覆值
        NSDictionary *currentBattles = [dataDic objectForKey:@"battles"][[currentIndex intValue]];
        _upModel = [UpgradeModel mj_objectWithKeyValues:currentBattles];
        [self setData];

        pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"sit",@"memberId":self.membID,@"index":currentIndex,@"subindex":currentSeatIndex};

    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"sit"])
    {//坐、准备
         _start.hidden = NO;
        [self setData];

    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"prepare"])
    {//准备后，变成撤销
        NSString *ID = [NSString stringWithFormat:@"%@",[dataDic objectForKey:@"id"]];
        if ([ID isEqualToString:self.membID]) {//自己的准备,变成撤销
            _start.hidden = NO;
            [_start setImage:[UIImage imageNamed:@"btnWithdraw"] forState:UIControlStateNormal];
            [_start addTarget:self action:@selector(withdrawAct) forControlEvents:UIControlEventTouchUpInside];

        }
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"withdraw"])
    {//撤销后，准备
        NSString *ID = [NSString stringWithFormat:@"%@",[dataDic objectForKey:@"id"]];
        if ([ID isEqualToString:self.membID]) {//自己的撤销，变成准备
            [_start setImage:[UIImage imageNamed:@"btnPrepare"] forState:UIControlStateNormal];
            [_start addTarget:self action:@selector(prepareAct) forControlEvents:UIControlEventTouchUpInside];
        }
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"melee"])
    {//发牌与抢庄
        _start.hidden = YES;
        pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"dealAndScramble"};
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"dealAndScramble"])
    {
        _start.hidden = YES;
        self.brightView.dataDic = dataDic;
        [self setData];
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"getBattle"])//作战
    {
        NSString *index = [NSString stringWithFormat:@"%@",_upModel.index];
        if ([index isEqualToString:currentIndex]) {//是当前自己桌子的时候
            if ([_upModel.phase isEqualToString:@"等待"]) {
//                _start.hidden = NO;

            }else {
                [_brightView hidden];
                _start.hidden = YES;
                [self setData];
            }
        }
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"second"])//秒
    {
        _start.hidden = YES;
//        [self setData];

    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"mandate"])//托管
    {
        pardic = @{@"sessionId":self.sessionId,@"command":@"upgrade",@"subcommand":@"getBattle"};//得到作战
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"step"]) {//步骤
        [self setData];
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"scramble"]) {//抓取
        [self setData];
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"skip"]) {//跳过
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"scramble"]) {//抓取
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"abandon"]) {//抛弃
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"clear"]) {//升级/清空

        [[NSNotificationCenter defaultCenter]postNotificationName:kNotification_ClearMessagePoker object:nil];
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"inquiry"]) {//升级/询问
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"hint"]) {//升级/提示
        [self setData];
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"hit"]) {//升级/打牌
        [self setData];

    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"finishRound"]) {//升级/结束轮
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"end"]) {//升级/结束
        
    }else if ([command isEqualToString:@"upgrade"]&&[_upModel.subcommand isEqualToString:@"restore"]) {//    升级/复位
        _start.hidden = NO;
    }

    if (pardic != nil) {
        NSLog(@"请求参数=%@",pardic);
        NSString *parmStr = [pardic mj_JSONString];
        [webSocket send:parmStr];
    }
}
#pragma mark setData
//设置牌的数据
- (void)setData {
    
    NSString *currentPlayingCardDesignation = _upModel.currentPlayingCardDesignation;//当前的级
    [[NSUserDefaults standardUserDefaults]setObject:currentPlayingCardDesignation forKey:@"currentPlayingCardDesignation"];
    //会员牌
    NSArray *memberCards = _upModel.memberCards[0];
    //允许出的牌
    NSArray *memberAllowableCardIds = _upModel.memberAllowableCardIds[0];
    //会员提示的牌id
    NSArray *memberHintingCardIds = _upModel.memberHintingCardIds[0];
    
    NSString *mySeatIndex = _upModel.currentSeatIndex;
    if ([mySeatIndex isEqualToString:currentSeatIndex]) {//d轮到我出牌的时候
        _mineview.allowPost = YES;
        _mineview.memberHintingCardIds = memberHintingCardIds;
    }else
    {
        _mineview.allowPost = NO;

    }
    //我的牌
    NSMutableArray *cardsArr = [NSMutableArray array];
    cardsArr = [PokerModel mj_objectArrayWithKeyValuesArray:memberCards];
    _mineview.memberAllowableCardIds = memberAllowableCardIds;
    _mineview.arr = cardsArr;
    
    //座位
    seatsArr = [NSMutableArray array];
    seatsArr = [SeatsModel mj_objectArrayWithKeyValuesArray:_upModel.seats];
    //托管
    NSArray *mandateds = _upModel.mandateds;
    if (mandateds.count >0) {
        BOOL mandated = [mandateds[0] boolValue];
        if (mandated) {
            _trusteeship.selected=YES;
        }else
        {
            _trusteeship.selected=NO;
        }
    }
    
    [self setSeatsData];
    [self setHitPokerData];
}

//设置头像名称
- (void)setSeatsData {
    for (SeatsModel *model in seatsArr) {
        NSString *index = model.index;
        SeatMembModel *memmodel = model.member;
        if ([index isEqualToString:@"0"]) {//自己
            if (memmodel.ID.length>0) {
                _mineview.smodel = memmodel;
            }
        }
        if ([index isEqualToString:@"3"]) {//上家
            if (memmodel.ID.length>0) {
                _previousView.smodel = memmodel;
                _previousView.hidden = NO;

            }else{
                _previousView.hidden = YES;
            }
        }
        if ([index isEqualToString:@"2"]) {//对家
            if (memmodel.ID.length>0) {
                _oppoView.smodel = memmodel;
                _oppoView.hidden = NO;

            }else{
                _oppoView.hidden = YES;

            }
        }
        if ([index isEqualToString:@"1"]) {//下家
            if (memmodel.ID.length>0) {
                _nextView.smodel = memmodel;
                _nextView.hidden = NO;
            }else{
                _nextView.hidden = YES;//s下线

            }
        }
    }
}
//发牌数据
- (void)setHitPokerData {
    NSArray *mineHitArr = [PokerModel mj_objectArrayWithKeyValuesArray:_upModel.memberHittingCards[0]];
    [self initHitPokerView:mineHitArr];
    //上家
    NSArray *presiousHitArr = [PokerModel mj_objectArrayWithKeyValuesArray:_upModel.memberHittingCards[3]];
    _previousView.hitArr = presiousHitArr;
//对家
    NSArray *oppositHitArr = [PokerModel mj_objectArrayWithKeyValuesArray:_upModel.memberHittingCards[2]];
    _oppoView.hitArr = oppositHitArr;
    //下家
    NSArray *nextHitArr = [PokerModel mj_objectArrayWithKeyValuesArray:_upModel.memberHittingCards[1]];
    _nextView.hitArr = nextHitArr;

}
//清空出牌
- (void)clear {
    if (_hitBgView )
    {
        [_hitBgView removeFromSuperview];
    }
}
// 竖屏
- (void)setVerticalScreen {
    if (_isRotate == YES) {
        _isRotate = NO;
        dispatch_async(dispatch_get_main_queue(), ^{
            [self forceOrientationPortrait];
            
            BaseNavViewController *navi = (BaseNavViewController *)self.navigationController;
            navi.interfaceOrientation = UIInterfaceOrientationPortrait;
            navi.interfaceOrientationMask = UIInterfaceOrientationMaskPortrait;
            
            [[UIDevice currentDevice] setValue:@(UIDeviceOrientationPortrait) forKey:@"orientation"];
            [UIViewController attemptRotationToDeviceOrientation];
        });
    }
}
// 横屏
- (void)setHorizontalScreen {
    if (_isRotate == NO) {
        _isRotate = YES;
        [self forceOrientationLandscape];
        
        BaseNavViewController *nav = (BaseNavViewController *)self.navigationController;
        nav.interfaceOrientation = UIInterfaceOrientationLandscapeRight;
        nav.interfaceOrientationMask = UIInterfaceOrientationMaskLandscapeRight;
        
        [[UIDevice currentDevice] setValue:@(UIInterfaceOrientationLandscapeRight) forKey:@"orientation"];
        [UIViewController attemptRotationToDeviceOrientation];
        
    }
}
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}


@end
