//
//  BrightMainView.h
//  ZhongLv
//
//  Created by iOSlmm on 2018/10/24.
//  Copyright © 2018年 Zhonglv. All rights reserved.
//

#import "BaseView.h"

NS_ASSUME_NONNULL_BEGIN
typedef void (^ScrambleBlock) (int index);

@interface BrightMainView : BaseView
@property (nonatomic,strong)NSDictionary *dataDic;
@property (weak, nonatomic) IBOutlet UIImageView *spadeImg;
@property (weak, nonatomic) IBOutlet UILabel *sapdeNum;

@property (weak, nonatomic) IBOutlet UIImageView *heartImg;
@property (weak, nonatomic) IBOutlet UILabel *heartNum;

@property (weak, nonatomic) IBOutlet UIImageView *clubImg;
@property (weak, nonatomic) IBOutlet UILabel *clubNum;

@property (weak, nonatomic) IBOutlet UIImageView *diamondImg;
@property (weak, nonatomic) IBOutlet UILabel *diamondNum;

@property (weak, nonatomic) IBOutlet UIImageView *ntImg;
@property (copy, nonatomic)ScrambleBlock block;

- (void)show;
- (void)hidden;
@end

NS_ASSUME_NONNULL_END
