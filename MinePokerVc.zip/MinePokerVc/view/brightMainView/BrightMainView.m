//
//  BrightMainView.m
//  ZhongLv
//
//  Created by iOSlmm on 2018/10/24.
//  Copyright © 2018年 Zhonglv. All rights reserved.
//

#import "BrightMainView.h"

@implementation BrightMainView
- (void)setupUI
{
    NSLog(@"z亮主");
}
- (void)setDataDic:(NSDictionary *)dataDic
{
    _dataDic = dataDic;
    NSArray *colourCounts = [dataDic objectForKey:@"colourCounts"][0];//花色计数
    _sapdeNum.text = [NSString stringWithFormat:@"%@",colourCounts[2]];
    _heartNum.text = [NSString stringWithFormat:@"%@",colourCounts[3]];
    _clubNum.text = [NSString stringWithFormat:@"%@",colourCounts[4]];
    _diamondNum.text = [NSString stringWithFormat:@"%@",colourCounts[5]];

    NSArray *colourGrabbings = [dataDic objectForKey:@"colourGrabbings"][0];//花色抓取数
    BOOL index0 = [colourGrabbings[0] boolValue];
    BOOL index1 = [colourGrabbings[1] boolValue];
    if (index0 || index1) {//  -1 2345
        NSLog(@"可以点击");
        _ntImg.image = [UIImage imageNamed:@"nt"];
        [_ntImg addTapActionWithBlock:^(UIGestureRecognizer *gestureRecoginzer) {
            if (_block) {
                _block(-1);
            }
        }];
    }else
    {
        _ntImg.image = [UIImage imageNamed:@"ntd"];
    }
    BOOL index2 = [colourGrabbings[2] boolValue];
    BOOL index3 = [colourGrabbings[3] boolValue];
    BOOL index4 = [colourGrabbings[4] boolValue];
    BOOL index5 = [colourGrabbings[5] boolValue];
    NSLog(@"抓取花色%@",colourGrabbings);
    if (index2==YES) {
        [_spadeImg addTapActionWithBlock:^(UIGestureRecognizer *gestureRecoginzer) {
            if (_block) {
                _block(2);
            }
        }];
    }
    if (index3==YES) {
        [_heartImg addTapActionWithBlock:^(UIGestureRecognizer *gestureRecoginzer) {
            if (_block) {
                _block(3);
            }
        }];
    }
    if (index4==YES) {
        [_clubImg addTapActionWithBlock:^(UIGestureRecognizer *gestureRecoginzer) {
            if (_block) {
                _block(3);
            }
        }];
    }
    if (index5==YES) {
        [_diamondImg addTapActionWithBlock:^(UIGestureRecognizer *gestureRecoginzer) {
            if (_block) {
                _block(4);
            }
        }];
    }
    _spadeImg.image = index2==YES?[UIImage imageNamed:@"spade"]: [UIImage imageNamed:@"spaded"];
    _heartImg.image = index3==YES?[UIImage imageNamed:@"heart"]: [UIImage imageNamed:@"heartd"];
    _clubImg.image = index4==YES?[UIImage imageNamed:@"club"]: [UIImage imageNamed:@"clubd"];
    _diamondImg.image = index5==YES?[UIImage imageNamed:@"diamond"]: [UIImage imageNamed:@"diamondd"];

}
- (void)show
{
//    self.hidden = NO;
}
- (void)hidden
{
    self.hidden = YES;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
