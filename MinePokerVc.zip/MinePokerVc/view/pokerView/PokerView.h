//
//  PokerView.h
//  PokerDemo
//
//  Created by iOSlmm on 2018/10/16.
//  Copyright © 2018年 iOSlmm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PokerModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface PokerView : UIView
- (instancetype)initWithFrame:(CGRect)frame;
@property (nonatomic,strong)UIImageView *img;
@property (nonatomic,strong)UILabel *nameL;
@property (nonatomic,strong)UIImageView *mainImg;//主牌
@property (nonatomic,strong)UIButton *btn;
@property (nonatomic,assign)BOOL useGester;//是否打开手势
@property (nonatomic,assign)BOOL clickPoker;//是否选中上移
@property (nonatomic,assign) BOOL main;   //是否是主牌
@property (nonatomic,strong)UIView *maskView;//遮罩视图
@property (nonatomic,strong)PokerModel *model;
@end

NS_ASSUME_NONNULL_END
