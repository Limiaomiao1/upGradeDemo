//
//  PokerView.m
//  PokerDemo
//
//  Created by iOSlmm on 2018/10/16.
//  Copyright © 2018年 iOSlmm. All rights reserved.
//

#import "PokerView.h"
@interface PokerView()

@end
@implementation PokerView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {

        self.backgroundColor = [UIColor clearColor];
//        [self addSubview:self.nameL];
        [self addSubview:self.img];
        [self addSubview:self.btn];
        [self addSubview:self.mainImg];
        [self addSubview:self.maskView];
       
    }
    return self;
}
- (void)setModel:(PokerModel *)model
{
    _model = model;
    self.main = _model.main;
//    NSLog(@"allow%d",_model.allow);
    self.hidden = _model.allow;
    if (_model.allow) {
        self.hidden = YES;
    }else {
        self.hidden = NO;
    }
    NSString *colour = _model.colour;
    NSString *currentPlayingCardDesignation = [[NSUserDefaults standardUserDefaults]objectForKey:@"currentPlayingCardDesignation"];
    //截掉当前的等级
    if ([colour containsString:currentPlayingCardDesignation]) {
        colour  = [colour stringByReplacingOccurrencesOfString:currentPlayingCardDesignation withString:@""];
        _model.colour = colour;
    }
    self.img.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@%@",colour,_model.designation]];
}
//是否是主牌
- (void)setMain:(BOOL)main
{
    _main = main;
    if (_main) {
        _mainImg.hidden = NO;
    }else
    {
        _mainImg.hidden = YES;
    }
}
//轻扫手势触发方法
-(void)swipeGesture:(id)sender
{
    NSLog(@"----");
}
- (UILabel *)nameL
{
    
    if (!_nameL) {
        _nameL = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 20, 15)];
        _nameL.textAlignment = 1;
    }
    return _nameL;
}
- (UIImageView *)img
{
    if (!_img) {
        _img = [[UIImageView alloc]initWithFrame:self.bounds];
        _img.contentMode = UIViewContentModeScaleToFill;
    }
    return _img;
}
- (UIImageView *)mainImg
{
    if (!_mainImg) {
        _mainImg = [[UIImageView alloc]init];
        _mainImg.frame = CGRectMake(2, self.height-(17), (15), (15));
        _mainImg.image = [UIImage imageNamed:@"mainstar"];
        _mainImg.hidden = YES;
    }
    return _mainImg;
}
- (UIButton *)btn
{
    if (!_btn) {
        _btn = [UIButton buttonWithType:UIButtonTypeCustom];
        _btn.frame = self.bounds;
        [_btn addTarget:self action:@selector(choosePoker:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _btn;
}
- (UIView *)maskView
{
    if (!_maskView) {
        _maskView = [[UIView alloc]initWithFrame:self.bounds];
        _maskView.alpha = 0.3;
        _maskView.backgroundColor = [UIColor blackColor];
        _maskView.hidden = YES;
        _maskView.layer.cornerRadius = 3;
        _maskView.clipsToBounds = YES;
    }
    return _maskView;
}

- (void)setClickPoker:(BOOL)clickPoker
{
    _clickPoker = clickPoker;
    if (_clickPoker) {
        [UIView animateWithDuration:0.1 animations:^{
            // 平移(参数为X轴和Y轴的平移数)
            self.transform = CGAffineTransformMakeTranslation(0, -30);
          
        }];
    }else
    {
        [UIView animateWithDuration:0.1 animations:^{
            // 平移(参数为X轴和Y轴的平移数)
            self.transform = CGAffineTransformMakeTranslation(0, 0);

        }];
    }
}
- (void)setUseGester:(BOOL)useGester
{
    _useGester = useGester;
    if (!_useGester) {
        self.userInteractionEnabled = NO;
    }
}
- (void)choosePoker:(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected) {
        NSLog(@"---");
        [UIView animateWithDuration:0.1 animations:^{
            // 平移(参数为X轴和Y轴的平移数)
            self.transform = CGAffineTransformMakeTranslation(0, -20);
        }];
    }else
    {
        NSLog(@"++");
        [UIView animateWithDuration:0.1 animations:^{
            // 平移(参数为X轴和Y轴的平移数)
            self.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
    }
}

#pragma mark - 在触摸方面开发时，只针对touches进行处理
#pragma mark - 触摸开始 在一次触摸事件中 只会执行一次
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
////    NSLog(@"开始%@",touches);
//}
//#pragma mark - 触摸移动  在一次触摸事件中会执行多次
//- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    //1.从nsset中取出touch对象
//    //通常在单点触摸时。可以使用[touches anyObject] 取出UITouch对象
//    UITouch *touch = [touches anyObject];
//    //2.要知道手指触摸的位置
//    CGPoint location = [touch locationInView:self];
//    //2.1对位置进行修正
//    
//    CGPoint pLocation = [touch previousLocationInView:self];
//    CGPoint deltaP = CGPointMake(location.x - pLocation.x, location.y-pLocation.y);
//    [self setClickPoker:YES];
//    //    CGPoint newCenter = CGPointMake(self.redView.center.x + deltaP.x, self.redView.center.y + deltaP.y);
//    //    [self.redView setCenter:newCenter];
////    NSLog(@"移动");
//}
////其中视图如果自己不进行设置则为单点触摸，所以可以使用 [touches anyObject] 获得uitouch对象，
////test view
//
//- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    NSLog(@"=========> test view touchs Ended");
//}
//- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    NSLog(@"=========> test view touchs Cancelled");
//}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
