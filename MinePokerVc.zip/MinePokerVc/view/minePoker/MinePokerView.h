//
//  MinePokerView.h
//  PokerDemo
//
//  Created by iOSlmm on 2018/10/16.
//  Copyright © 2018年 iOSlmm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SeatsModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MinePokerView : UIView
- (instancetype)initWithFrame:(CGRect)frame arr:(NSArray *)arr;
@property (nonatomic,strong)UIView *bgView;
@property (nonatomic,assign)NSInteger pokerNumber;
@property (nonatomic,assign)NSArray *arr;
@property (nonatomic,strong)UIImageView *head;
@property (nonatomic,strong)UILabel *statusL;
@property (nonatomic,strong)SeatMembModel *smodel;
@property (nonatomic,strong)NSArray *memberAllowableCardIds;//会员允许出的牌
@property (nonatomic,strong)NSArray *memberHintingCardIds;//会员提示出的牌


@property (nonatomic,assign)BOOL allowPost;//是否允许出牌模式

@end

NS_ASSUME_NONNULL_END
