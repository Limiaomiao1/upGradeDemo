
//
//  MinePokerView.m
//  PokerDemo
//
//  Created by iOSlmm on 2018/10/16.
//  Copyright © 2018年 iOSlmm. All rights reserved.
//

#import "MinePokerView.h"
#import "PokerView.h"
#import "PokerModel.h"
#define countcoordinatesY(A) [UIScreen mainScreen].bounds.size.height * (A / 375.f)

@interface MinePokerView()
@property (nonatomic,strong)PokerView *pview;
@property (nonatomic,strong)NSMutableArray *piArr;

@end
@implementation MinePokerView
- (instancetype)initWithFrame:(CGRect)frame arr:(nonnull NSArray *)arr
{
    if (self = [super initWithFrame:frame]) {
        _piArr = [NSMutableArray array];
        [self initHead];
    }
    return self;
}
- (void)initHead {
    _head = [[UIImageView alloc]initWithFrame:CGRectMake(countcoordinatesX(20), countcoordinatesX(80), countcoordinatesX(40), countcoordinatesX(40))];
    _head.backgroundColor = [UIColor yellowColor];
    [self addSubview:_head];
    _statusL = [[UILabel alloc]initWithFrame:CGRectMake(countcoordinatesX(70),countcoordinatesX(80), countcoordinatesX(200), countcoordinatesX(40))];
    _statusL.textColor = [UIColor whiteColor];
    _statusL.font = [UIFont systemFontOfSize:12];
    _statusL.text = @"用户名";
    [self addSubview:_statusL];
}
- (void)setSmodel:(SeatMembModel *)smodel
{
    _smodel = smodel;
    _statusL.text = [NSString stringWithFormat:@"%@ %@",_smodel.nickname,_smodel.status];
    NSString *imgurl = [NSString stringWithFormat:@"%@%@.jpg",POKER_IMG,_smodel.ID];
    [_head sd_setImageWithURL:[NSURL URLWithString:imgurl]];
}

- (void)setArr:(NSArray *)arr
{
    _arr = arr;
    [self initPokerView];
}
- (void)initPokerView
{
    if (_bgView ) {
        [_bgView removeFromSuperview];
    }

    _bgView = [[UIView alloc]initWithFrame:CGRectMake((self.width-countcoordinatesY(62))/2, 0,(_arr.count-1)*countcoordinatesY(20)+countcoordinatesY(62), countcoordinatesY(80))];
    [self addSubview:_bgView];
    
    for (int i = 0; i<_arr.count; i++) {
        self.pview = [[PokerView alloc]initWithFrame:CGRectMake(i*countcoordinatesY(20), 0, countcoordinatesY(62), countcoordinatesY(80))];
        _bgView.frame = CGRectMake((self.width-countcoordinatesY(62)-i*countcoordinatesY(20))/2, 0,(_arr.count-1)*countcoordinatesY(20)+countcoordinatesY(62), countcoordinatesY(80));
        self.pview.tag = i;
        PokerModel *model = _arr[i];
        if (_allowPost) {//到自己出牌
            //判断是否允许出牌
            for (int i = 0;i<_memberAllowableCardIds.count; i++ ) {
                NSString *allowID =[NSString stringWithFormat:@"%@", _memberAllowableCardIds[i]];
                if ([allowID isEqualToString:model.ID]) {//可以出牌
                    self.pview.maskView.hidden = YES;
                }else
                {//不可以出牌
                   self.pview.maskView.hidden = NO;
                }
            }
            //判断是否允许出牌
            for (int i = 0;i<_memberHintingCardIds.count; i++ ) {
                NSString *hintingID =[NSString stringWithFormat:@"%@", _memberHintingCardIds[i]];
                if ([hintingID isEqualToString:model.ID]) {//提示出牌
                    self.pview.clickPoker = YES;
                }else
                {//不提示出牌
                    self.pview.clickPoker = NO;
                }
            }
        }else {
            self.pview.maskView.hidden = YES;
        }
    
        self.pview.model = model;
        [self.bgView addSubview:self.pview];
        [self.piArr addObject:self.pview];
    }
}

- (void)delayMethod:(int)i {
    
}
/*
//轻扫手势触发方法
-(void)swipeGesture:(id)sender
{
    UISwipeGestureRecognizer *swipe = sender;
    if (swipe.direction == UISwipeGestureRecognizerDirectionLeft)
    {
        
        //向左轻扫做的事情
        NSLog(@"00");
    }
    
    if (swipe.direction == UISwipeGestureRecognizerDirectionRight)
    {
        
        //向右轻扫做的事情
        NSLog(@"1111");

    }
}
#pragma mark - 在触摸方面开发时，只针对touches进行处理
#pragma mark - 触摸开始 在一次触摸事件中 只会执行一次
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"开始%@",touches);
    
}

#pragma mark - 触摸移动  在一次触摸事件中会执行多次

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    //1.从nsset中取出touch对象
    //通常在单点触摸时。可以使用[touches anyObject] 取出UITouch对象
    UITouch *touch = [touches anyObject];
//    NSLog(@"移动%@",touches);

    PokerView *pview = (PokerView *)touch.view;
//    pview.clickPoker = YES;
    //2.要知道手指触摸的位置
    CGPoint location = [touch locationInView:self];
    //2.1对位置进行修正
    for (PokerView *pview in self.subviews) {
        if ([pview.layer containsPoint:location]) {
//            pview.clickPoker = YES;
        }
    }
    CGPoint pLocation = [touch previousLocationInView:self];
    CGPoint deltaP = CGPointMake(location.x - pLocation.x, location.y-pLocation.y);

    NSLog(@"(%f,%f)---(%f,%f)",location.x,location.y,pLocation.x,pLocation.y);
}
//其中视图如果自己不进行设置则为单点触摸，所以可以使用 [touches anyObject] 获得uitouch对象，
//test view

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"=========> test view touchs Ended");
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"=========> test view touchs Cancelled");
    UITouch *touch = [touches anyObject];
    //    NSLog(@"移动%@",touches);
    //2.要知道手指触摸的位置
    CGPoint location = [touch locationInView:self];
    //2.1对位置进行修正
    for (PokerView *pview in self.subviews) {
        if ([pview.layer containsPoint:location]) {
//            pview.clickPoker = YES;
        }
    }
}
*/
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
