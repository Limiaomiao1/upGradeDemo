//
//  LeftPokerView.h
//  PokerDemo
//
//  Created by iOSlmm on 2018/10/18.
//  Copyright © 2018年 iOSlmm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SeatsModel.h"
#import "PokerModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface PreviousPokerView : UIView
@property (nonatomic,strong)UIImageView *headImg;
@property (nonatomic,strong)UILabel *nameL;
@property (nonatomic,strong)UILabel *statusL;
@property (nonatomic,strong)SeatMembModel *smodel;
@property (nonatomic,strong)NSArray *hitArr;//f出的牌
@property (nonatomic,strong)UIView *pokerBgView;//背景

- (instancetype)initWithFrame:(CGRect)frame;

@end

NS_ASSUME_NONNULL_END
