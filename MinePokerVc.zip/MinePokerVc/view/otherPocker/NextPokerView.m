//
//  RightPokerView.m
//  PokerDemo
//
//  Created by iOSlmm on 2018/10/18.
//  Copyright © 2018年 iOSlmm. All rights reserved.
//

#import "NextPokerView.h"
#import "PokerView.h"
#define countcoordinatesY(A) [UIScreen mainScreen].bounds.size.height * (A / 375.f)

@implementation NextPokerView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self initUserInfo];
        [self initPokerView];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(clear) name:kNotification_ClearMessagePoker object:nil];

    }
    return self;
}
- (void)initUserInfo {
    _headImg = [[UIImageView alloc]initWithFrame:CGRectMake(self.width-countcoordinatesX(60), 0, countcoordinatesX(40), countcoordinatesX(40))];
    _headImg.backgroundColor = [UIColor yellowColor];
    [self addSubview:_headImg];
    _nameL = [[UILabel alloc]initWithFrame:CGRectMake(self.width-70, 55, 70, 15)];
    _nameL.text = @"下家";
    _nameL.textColor = [UIColor whiteColor];
    _nameL.textAlignment = 1;
    _nameL.font = [UIFont systemFontOfSize:12];
    [self addSubview:_nameL];
    
    _statusL = [[UILabel alloc]initWithFrame:CGRectMake(self.width-70, 70, 70, 15)];
    _statusL.textColor = [UIColor whiteColor];
    _statusL.text = @"状态";
    _statusL.textAlignment = 1;
    _statusL.font = [UIFont systemFontOfSize:12];
    [self addSubview:_statusL];
}

- (void)setHitArr:(NSArray *)hitArr
{
    _hitArr = hitArr;
    [self initPokerView];
}

- (void)initPokerView
{
    if (_pokerBgView ) {
        [_pokerBgView removeFromSuperview];
    }
    
    _pokerBgView = [[UIView alloc]initWithFrame:CGRectMake(self.width-75-countcoordinatesY(50)-(_hitArr.count-1)*countcoordinatesY(15), countcoordinatesY(10),(_hitArr.count-1)*countcoordinatesY(15)+countcoordinatesY(39), countcoordinatesY(50))];
    _pokerBgView.hidden = YES;

    [self addSubview:_pokerBgView];
    for (int i = 0; i<_hitArr.count; i++) {
        PokerView *pview = [[PokerView alloc]initWithFrame:CGRectMake(i*countcoordinatesY(15), countcoordinatesY(10), countcoordinatesY(39), countcoordinatesY(50))];
        PokerModel *model = _hitArr[i];
        pview.model = model;
        _pokerBgView.hidden = NO;
        [_pokerBgView addSubview:pview];
    }
}
- (void)setSmodel:(SeatMembModel *)smodel
{
    _smodel = smodel;
    _nameL.text = _smodel.nickname;
    _statusL.text = _smodel.status;
    NSString *imgurl = [NSString stringWithFormat:@"%@%@.jpg",POKER_IMG,_smodel.ID];
    [_headImg sd_setImageWithURL:[NSURL URLWithString:imgurl]];
}
//清空出牌
- (void)clear {
    if (_pokerBgView )
    {
        [_pokerBgView removeFromSuperview];
    }
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
