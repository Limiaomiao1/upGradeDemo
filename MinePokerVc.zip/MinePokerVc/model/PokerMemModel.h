//
//  PokerMemModel.h
//  ZhongLv
//
//  Created by iOSlmm on 2018/10/22.
//  Copyright © 2018年 Zhonglv. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PokerMemModel : NSObject
@property (nonatomic, strong) NSString *command;    // 命令
@property (nonatomic, strong) NSString *sessionId;  // session
@property (nonatomic, strong) NSString *subcommand; // 子命令
@property (nonatomic, strong) NSString *memberId;   // member

// 登录
- (NSString *)login:(NSString *)user pass:(NSString *)pass;
// 踹
- (NSString *)kickoff;
// 上线会员
- (NSString *)onlineMember;
// 得到游戏
- (NSString *)getGames;
// 根据名称得到游戏
- (NSString *)getGameByName;
// 得到作战
- (NSString *)getBattles;
// 升级/坐
- (NSString *)sit;
// 升级/准备
- (NSString *)prepare;
// 得到作战(桌子索引)
- (NSString *)getBattle:(NSString *)index;



// 是否在线
- (BOOL)isOnline:(NSDictionary *)data;

@end

NS_ASSUME_NONNULL_END
