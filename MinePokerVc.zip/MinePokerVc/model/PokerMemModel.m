//
//  PokerMemModel.m
//  ZhongLv
//
//  Created by iOSlmm on 2018/10/22.
//  Copyright © 2018年 Zhonglv. All rights reserved.
//

#import "PokerMemModel.h"

@implementation PokerMemModel
// 登录
- (NSString *)login:(NSString *)user pass:(NSString *)pass {
    NSDictionary *param = [NSDictionary dictionaryWithObjectsAndKeys:
                           @"login", @"command",
                           user, @"account",
                           pass, @"cipher",
                           self.sessionId, @"sessionId", nil];
    return [param mj_JSONString];
}

// 踹
- (NSString *)kickoff {
    NSDictionary *param = @{@"sessionId": _sessionId,
                            @"command": @"kickoff",
                            @"memberId": _memberId,
                            @"currentSessionId": _sessionId
                            };
    return [param mj_JSONString];
}

// 上线会员
- (NSString *)onlineMember {
    NSDictionary *param = @{@"command": @"onlineMember",
                            @"sessionId": _sessionId,
                            @"memberId": _memberId,
                            @"currentSessionId": _sessionId
                            };
    return [param mj_JSONString];
}

// 得到游戏
- (NSString *)getGames {
    NSDictionary *param = @{@"command": @"getGames",
                            @"sessionId": _sessionId};
    return [param mj_JSONString];
}
// 根据名称得到游戏
- (NSString *)getGameByName {
    NSDictionary *param = @{
                            @"sessionId": _sessionId,
                            @"command": @"getGameByName",
                            @"gameName": @"升级"
                            };
    return [param mj_JSONString];
}
// 得到作战
- (NSString *)getBattles {
    NSDictionary *param = @{
                            @"sessionId": _sessionId,
                            @"command": @"upgrade",
                            @"subcommand": @"getBattles"
                            };
    return [param mj_JSONString];
}
// 升级/坐
- (NSString *)sit {
    NSDictionary *param = @{
                            @"sessionId": _sessionId,
                            @"command": @"upgrade",
                            @"subcommand": @"sit",
                            @"memberId": _memberId,
                            @"index": @"0",
                            @"subindex": @"0",
                            };
    return [param mj_JSONString];
}
// 升级/准备
- (NSString *)prepare {
    NSDictionary *param = @{
                            @"sessionId": _sessionId,
                            @"command": @"upgrade",
                            @"subcommand": @"prepare",
                            @"memberId": _memberId
                            };
    return [param mj_JSONString];
}
// 得到作战
- (NSString *)getBattle:(NSString *)index {
    NSDictionary *param = @{
                            @"sessionId": _sessionId,
                            @"command": @"upgrade",
                            @"subcommand": @"getBattle",
                            @"index": index
                            };
    return [param mj_JSONString];
}




// 是否在线
- (BOOL)isOnline:(NSDictionary *)data {
    if ([[data allKeys] containsObject:@"online"] && [data[@"online"] boolValue] == YES) {
        return YES;
    }
    return NO;
}



@end
