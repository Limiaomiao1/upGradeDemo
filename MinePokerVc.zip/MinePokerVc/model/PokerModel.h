//
//  PokerModel.h
//  ZhongLv
//
//  Created by iOSlmm on 2018/10/22.
//  Copyright © 2018年 Zhonglv. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PokerModel : NSObject
@property (nonatomic, strong) NSString *big;    //
@property (nonatomic, strong) NSString *capacity;  //
@property (nonatomic, strong) NSString *colour; //
@property (nonatomic, strong) NSString *currentCapacity;   //
@property (nonatomic, strong) NSString *designation;    //
@property (nonatomic, strong) NSString *holed;  //
@property (nonatomic, strong) NSString *pokerid; //
@property (nonatomic, assign) BOOL main;   //
@property (nonatomic, strong) NSArray *sessionIds;   //
@property (nonatomic, strong) NSString *sum;   //
@property (nonatomic, strong) NSString *ID;   //
@property (nonatomic, assign) BOOL allow;   //是否允许发牌


@end

NS_ASSUME_NONNULL_END
