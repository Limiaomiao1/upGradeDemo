//
//  UpgradeModel.h
//  ZhongLv
//
//  Created by iOSlmm on 2018/10/25.
//  Copyright © 2018年 Zhonglv. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UpgradeModel : NSObject
@property (nonatomic, strong) NSString *command;    // 命令
@property (nonatomic, strong) NSString *sessionId;  // session
@property (nonatomic, strong) NSString *subcommand; // 子命令
@property (nonatomic, strong) NSString *memberId;   // member
@property (nonatomic, strong) NSArray *seats;    // 座位
@property (nonatomic, strong) NSArray *memberCards;  // 会员牌
@property (nonatomic, strong) NSString *givenMainCards;  // 既定主牌
@property (nonatomic, strong) NSString *colourCounts; // 花色计数
@property (nonatomic, strong) NSString *colourGrabbings;   // 花色抓取
@property (nonatomic, strong) NSString *memberPreviousHittingCards;    // 会员先前出的牌
@property (nonatomic, strong) NSArray *memberHittingCards;  // 会员出的牌
@property (nonatomic, strong) NSArray *memberAllowableCardIds; // 会员允许的牌id
@property (nonatomic, strong) NSArray *memberHintingCardIds; // 会员提示的牌id
@property (nonatomic, strong) NSString *mainColour;   // 主色
@property (nonatomic, strong) NSString *openingSeatIndex;  // 发牌座位索引
@property (nonatomic, strong) NSString *currentSeatIndex; // 当前座位索引
@property (nonatomic, strong) NSString *lastMainSeatIndex;   // 上次主座位索引

@property (nonatomic, strong) NSString *index;    //桌子索引
@property (nonatomic, strong) NSString *currentPlayingCardDesignation;    //当前玩的牌称谓
@property (nonatomic, strong) NSArray *mandateds;    //托管
@property (nonatomic, strong) NSString *phase;    //阶段



@end

NS_ASSUME_NONNULL_END
