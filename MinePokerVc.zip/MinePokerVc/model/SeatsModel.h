//
//  SeatsModel.h
//  ZhongLv
//
//  Created by iOSlmm on 2018/10/23.
//  Copyright © 2018年 Zhonglv. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface SeatMembModel : NSObject
@property (nonatomic, strong) NSString *account;    //
@property (nonatomic, strong) NSString *currentSessionId;  //
@property (nonatomic, strong) NSString *experience; //
@property (nonatomic, strong) NSString *sessionIds;   //
@property (nonatomic, strong) NSString *head;   //
@property (nonatomic, strong) NSString *nickname;   //
@property (nonatomic, strong) NSString *ID;   //
@property (nonatomic, strong) NSString *online;   //
@property (nonatomic, strong) NSString *position;   //
@property (nonatomic, strong) NSString *sum;   //
@property (nonatomic, strong) NSString *status;   //

@end

@interface SeatsModel : NSObject
@property (nonatomic, strong) NSDictionary *battle;    //
@property (nonatomic, strong) NSString *index;  //
@property (nonatomic, strong) SeatMembModel *member; //
@property (nonatomic, strong) NSString *sessionIds;   //
@property (nonatomic, strong) NSString *sum;   //

@end


NS_ASSUME_NONNULL_END
