//
//  SeatsModel.m
//  ZhongLv
//
//  Created by iOSlmm on 2018/10/23.
//  Copyright © 2018年 Zhonglv. All rights reserved.
//

#import "SeatsModel.h"
@implementation SeatMembModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             // 模型属性: JSON key, MJExtension 会自动将 JSON 的 key 替换为你模型中需要的属性
             @"ID":@"id",
             };
}

@end
@implementation SeatsModel
+ (NSDictionary *)objectClassInArray{
    return @{
             @"member" : [SeatMembModel class],
             };
}

@end
